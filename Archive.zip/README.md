# page-editor

A chrome extension to toggle document.designMode
